<?php
echo '<h2>Selamat datang di Portal Beasiswa!</h2>';
?>