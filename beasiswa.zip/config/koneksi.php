<?php
$host = 'localhost'; $user = 'root'; $pass = ''; $db = 'beasiswa';
$conn = mysqli_connect($host, $user, $pass, $db);
?>