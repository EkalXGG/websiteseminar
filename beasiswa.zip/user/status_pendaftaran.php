<?php
// status_pendaftaran.php content
?>