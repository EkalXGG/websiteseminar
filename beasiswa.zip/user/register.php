<?php
// register.php content
?>