<?php
// admin dashboard.php content
?>